<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('dashboard');
});

Route::get('/login', function(){
	return view('login');
});
Route::get('/klubovi', function(){
	return view('klubovi');
});
Route::get('/dashboard', function(){
	return view('dashboard');
});
Route::get('/users', function(){
	return view('users');
});
Route::get('/objekti', function(){
	return view('objekti');
});
Route::get('/prijave', function(){
	return view('prijave');
});
Route::get('/news', function(){
	return view('news');
});
Route::get('/sportisti', function(){
	return view('sportisti');
});
Route::get('/unauth/news', function(){
	return view('unews');
});

Route::get('/unauth/klubovi', function(){
	return view('uklubovi');
});
Route::get('/unauth/sportisti', function(){
	return view('usportisti');
});
Route::get('/unauth/objekti', function(){
	return view('uobjekti');
});
Route::get('/unauth/priajve', function(){
	return view('uprijave');
});